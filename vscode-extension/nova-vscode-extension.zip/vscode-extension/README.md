# Nova Language — VS Code Extension

Dukungan bahasa Nova (`.nova`) untuk Visual Studio Code.

## Fitur

- **Syntax highlighting** — keyword, string, angka, boolean, operator, komentar, nama fungsi
- **Bracket matching** dan auto-closing untuk `{}`, `[]`, `()`, `""`, `''`
- **Komentar** — `Ctrl+/` untuk `//`, `Shift+Alt+A` untuk `/* */`
- **Auto indentation** — indent otomatis setelah `{`, outdent otomatis pada `}`
- **Ikon file** untuk `.nova`
- **Tombol Run** (`Ctrl+F5` / `Cmd+F5`) untuk menjalankan file lewat CLI `nova`

## Pemasangan (mode pengembangan)

1. Salin folder `vscode-extension/` ke folder extension VS Code:
   - Windows: `%USERPROFILE%\.vscode\extensions\nova-language`
   - macOS / Linux: `~/.vscode/extensions/nova-language`
2. Restart VS Code sepenuhnya (tutup semua jendela, bukan sekadar reload).
3. Buka file `.nova` mana pun.

## Verifikasi bahasa sudah terdeteksi

Buka file `.nova`, lalu lihat **status bar kanan bawah**:

- Tertulis **`Nova`** → berhasil
- Tertulis **`Plain Text`** → belum terdeteksi, lihat bagian Troubleshooting

## Troubleshooting

### Status bar masih "Plain Text"

Ikon file dan deteksi bahasa adalah dua hal terpisah. Ikon bisa muncul dari
icon theme walaupun bahasanya belum terdaftar. Pastikan `package.json` punya
blok `contributes.languages` dengan `"id": "nova"` dan `"extensions": [".nova"]`.

Kalau sudah ada tapi tetap Plain Text:

1. Jalankan `Developer: Reload Window` dari Command Palette (`Ctrl+Shift+P`)
2. Kalau masih gagal, restart VS Code sepenuhnya — perubahan `contributes`
   tidak selalu terbaca lewat reload window saja
3. Cek `Help > Toggle Developer Tools > Console` untuk pesan error dari
   extension (biasanya JSON yang salah format)

### Tidak ada warna sama sekali padahal status bar sudah "Nova"

Berarti bahasa terdeteksi tapi grammar gagal dimuat. Penyebab tersering:
`scopeName` di `nova.tmLanguage.json` tidak sama persis dengan `scopeName`
di `contributes.grammars`. Keduanya harus `source.nova`.

### Memaksa bahasa secara manual

Untuk mengetes cepat tanpa restart: klik tulisan bahasa di status bar, pilih
**Configure File Association for '.nova'**, lalu pilih **Nova**.

### Tombol Run tidak bekerja

Perintah `nova` harus tersedia di PATH. Dari folder project Nova, jalankan:

```bash
npm link
```

Lalu tes di terminal biasa: `nova --version`.

## Catatan tentang ikon file

Extension ini memakai `contributes.languages[].icon`, yang menampilkan ikon
hanya pada icon theme yang mendukungnya (Seti, tema bawaan VS Code). Kalau
Anda memakai icon theme pihak ketiga seperti Material Icon Theme, ikon Nova
mungkin tidak muncul karena tema tersebut menentukan ikonnya sendiri. Ini
batasan VS Code, bukan bug pada extension.

## Keterbatasan

- Belum ada IntelliSense / autocomplete — butuh Language Server (LSP), yang
  jauh lebih kompleks dan direncanakan untuk versi berikutnya
- Belum ada debugger breakpoint — tombol Run hanya menjalankan file di
  terminal, bukan debugging sungguhan. Debug Adapter Protocol diperlukan
  untuk itu
- Belum ada error squiggle di editor; error hanya tampil di terminal
