'use strict';

const vscode = require('vscode');

/** @type {vscode.Terminal | undefined} */
let novaTerminal;

function getTerminal() {
  if (!novaTerminal || novaTerminal.exitStatus !== undefined) {
    novaTerminal = vscode.window.createTerminal('Nova');
  }
  return novaTerminal;
}

function activate(context) {
  const runFile = vscode.commands.registerCommand('nova.runFile', async () => {
    const editor = vscode.window.activeTextEditor;

    if (!editor) {
      vscode.window.showErrorMessage('Tidak ada file yang sedang dibuka.');
      return;
    }

    if (editor.document.languageId !== 'nova') {
      vscode.window.showErrorMessage('File ini bukan file Nova (.nova).');
      return;
    }

    // Simpan dulu supaya yang dijalankan adalah versi terbaru
    if (editor.document.isDirty) {
      await editor.document.save();
    }

    const filePath = editor.document.uri.fsPath;
    const terminal = getTerminal();
    terminal.show(true);
    terminal.sendText(`nova "${filePath}"`);
  });

  context.subscriptions.push(runFile);

  // Bersihkan referensi kalau terminal ditutup pengguna
  context.subscriptions.push(
    vscode.window.onDidCloseTerminal((closed) => {
      if (closed === novaTerminal) {
        novaTerminal = undefined;
      }
    })
  );
}

function deactivate() {
  if (novaTerminal) {
    novaTerminal.dispose();
    novaTerminal = undefined;
  }
}

module.exports = { activate, deactivate };
